# ifndef GNL
#define GNL
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
// # define BUFFER_SIZE 10
char    *get_next_line(int fd);

#endif
